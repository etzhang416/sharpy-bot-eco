from sharpy.plans.acts import ActBase
from sc2 import AbilityId


class NoDoubleOrders(ActBase):
    """Don't use this for terrans, seriously!"""

    def __init__(self):
        super().__init__()
        self.last_cancel = -1

    async def execute(self) -> bool:
        for unit in self.ai.structures:
            if len(unit.orders) > 1:
                msg = f"{unit.type_id} has multiple orders!"
                if self.knowledge.is_chat_allowed:
                    await self.ai.chat_send(msg)

                self.knowledge.print("[DUPLICATE] " + msg)

                if self.last_cancel + 0.2 < self.ai.time:
                    self.knowledge.print("[DUPLICATE] " + "Cancelling!")
                    self.do(unit(AbilityId.CANCEL_LAST))
                    self.last_cancel = self.ai.time
        return True
